/*
Package schedule provides a simple scheduler for Go.

It can run a function at a given time, in a given duration, or repeatedly at a given interval.
*/
package schedule
