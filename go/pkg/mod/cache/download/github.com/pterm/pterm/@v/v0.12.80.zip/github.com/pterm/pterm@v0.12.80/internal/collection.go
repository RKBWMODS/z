package internal

// RandomStrings contains a list of random strings to use while testing.
var RandomStrings = []string{
	"hello world", "²³14234!`§=)$-.€@_&", "This is a sentence.", "This\nstring\nhas\nmultiple\nlines",
	"windows\r\nline\r\nendings", "\rtext",
}
